package com.tictactoe.Checkers;

public enum EGameStatus {
    NOT_RUNNING,
    RUNNING,
    WIN,
    LOSE,
    DRAW
}
