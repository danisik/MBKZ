package com.tictactoe.Data;

public class Constants {
    public static final int NO_PLAYER = 0;
    public static final int PLAYER_1_ID = 1;
    public static final int PLAYER_2_ID = 2;
}
