# MBKZ
Semestrální práce z předmětu KIV/MBKZ 2019/2020
